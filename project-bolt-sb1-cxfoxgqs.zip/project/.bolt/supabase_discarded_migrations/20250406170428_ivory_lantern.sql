/*
  # Add cities and location search functionality

  1. Extensions
    - PostGIS for spatial queries
    - pg_trgm for text search

  2. New Tables
    - `cities`
      - `id` (uuid, primary key)
      - `name` (text)
      - `department` (text)
      - `latitude` (double precision)
      - `longitude` (double precision)
      - `created_at` (timestamp with time zone)

  3. Functions
    - `calculate_distance`: Haversine formula for calculating distance between coordinates

  4. Security
    - Enable RLS on cities table
    - Add policy for viewing cities
*/

-- Add required extensions
CREATE EXTENSION IF NOT EXISTS postgis;
CREATE EXTENSION IF NOT EXISTS pg_trgm;

-- Create cities table
CREATE TABLE IF NOT EXISTS cities (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  name text NOT NULL,
  department text NOT NULL,
  latitude double precision NOT NULL,
  longitude double precision NOT NULL,
  created_at timestamptz DEFAULT now()
);

-- Create index for city name search
CREATE INDEX IF NOT EXISTS cities_name_idx ON cities USING gin (name gin_trgm_ops);

-- Enable RLS
ALTER TABLE cities ENABLE ROW LEVEL SECURITY;

-- Create policies
CREATE POLICY "Anyone can view cities"
  ON cities
  FOR SELECT
  TO authenticated
  USING (true);

-- Function to calculate distance between two points using Haversine formula
CREATE OR REPLACE FUNCTION calculate_distance(
  lat1 double precision,
  lon1 double precision,
  lat2 double precision,
  lon2 double precision
)
RETURNS double precision
LANGUAGE plpgsql
AS $$
DECLARE
  R double precision := 6371; -- Earth's radius in kilometers
  dlat double precision;
  dlon double precision;
  a double precision;
  c double precision;
BEGIN
  dlat := radians(lat2 - lat1);
  dlon := radians(lon2 - lon1);
  
  a := sin(dlat/2) * sin(dlat/2) +
       cos(radians(lat1)) * cos(radians(lat2)) *
       sin(dlon/2) * sin(dlon/2);
       
  c := 2 * atan2(sqrt(a), sqrt(1-a));
  
  RETURN R * c;
END;
$$;