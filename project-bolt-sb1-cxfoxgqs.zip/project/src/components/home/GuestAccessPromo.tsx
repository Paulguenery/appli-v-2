import React from 'react';
import { ArrowRight } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Link } from 'react-router-dom';

export function GuestAccessPromo() {
  // This component is now empty as we're removing the guest access functionality
  return null;
}