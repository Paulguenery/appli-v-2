import React from 'react';
import { Button } from '@/components/ui/button';
import { Link } from 'react-router-dom';

export function GuestAccessButton() {
  // This component is now empty as we're removing the guest access functionality
  return null;
}