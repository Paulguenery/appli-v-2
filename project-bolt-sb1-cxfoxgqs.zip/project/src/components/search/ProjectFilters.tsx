import React, { useState } from 'react';
import { Filter, Briefcase, Clock, Star, Code, Search, X, ArrowRight } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import * as Tabs from '@radix-ui/react-tabs';
import { motion } from 'framer-motion';

interface ProjectFiltersProps {
  onApplyFilters: (filters: any) => void;
}

export function ProjectFilters({ onApplyFilters }: ProjectFiltersProps) {
  const [searchTerm, setSearchTerm] = useState('');
  const [activeTab, setActiveTab] = useState('sector');
  const [selectedSector, setSelectedSector] = useState('');
  const [selectedSkills, setSelectedSkills] = useState<string[]>([]);
  const [selectedStage, setSelectedStage] = useState('');
  const [selectedDuration, setSelectedDuration] = useState('');

  // Move to next tab when a selection is made
  const handleNextTab = (currentTab: string) => {
    switch (currentTab) {
      case 'sector':
        setActiveTab('skills');
        break;
      case 'skills':
        setActiveTab('stage');
        break;
      case 'stage':
        setActiveTab('duration');
        break;
      default:
        break;
    }
  };

  const sectors = [
    '🧠 Technologie & Numérique',
    '📱 Communication & Marketing',
    '🛒 Commerce & Distribution',
    '🚀 Entrepreneuriat & Innovation',
    '🌿 Écologie & Impact',
    '🏥 Santé & Bien-être',
    '🎨 Création & Culture',
    '💼 Business & Finances',
    '📚 Éducation & Formation',
    '🌍 Voyage & Tourisme'
  ];

  const durations = [
    'Temps partiel',
    'Temps plein'
  ];

  const stages = [
    'Idée / Concept',
    'Prototype / MVP',
    'En développement',
    'Lancé / En croissance',
    'Mature / Établi'
  ];

  // Skills based on selected sector
  const getSkillsForSector = (sector: string) => {
    switch (sector) {
      case '🧠 Technologie & Numérique':
        return [
          'Développement web',
          'Développement mobile',
          'Intelligence artificielle',
          'Blockchain / Crypto',
          'Cybersécurité',
          'Réalité virtuelle / augmentée',
          'IOT (Objets connectés)',
          'Big Data & Data Science',
          'SaaS / Logiciels B2B',
          'UI/UX Design'
        ];
      case '📱 Communication & Marketing':
        return [
          'Marketing digital',
          'Publicité & médias',
          'Branding / Identité visuelle',
          'Community Management',
          'Relations presse',
          'SEO / SEA',
          'Influence & Réseaux sociaux',
          'Rédaction & Copywriting',
          'UI/UX Design'
        ];
      case '🛒 Commerce & Distribution':
        return [
          'E-commerce',
          'Retail / Boutique physique',
          'Dropshipping',
          'Marketplace / Plateforme',
          'Import / Export',
          'Économie circulaire',
          'Produits artisanaux',
          'UI/UX Design'
        ];
      default:
        return [
          'Développement web',
          'Développement mobile',
          'Marketing digital',
          'Gestion de projet',
          'Design / UX',
          'Vente / Business development',
          'Finance / Comptabilité',
          'Juridique',
          'RH / Recrutement',
          'Communication',
          'Stratégie',
          'UI/UX Design'
        ];
    }
  };

  const handleApply = () => {
    onApplyFilters({
      searchTerm,
      sector: selectedSector,
      duration: selectedDuration,
      stage: selectedStage,
      skills: selectedSkills
    });
  };

  const handleReset = () => {
    setSearchTerm('');
    setSelectedSector('');
    setSelectedSkills([]);
    setSelectedStage('');
    setSelectedDuration('');
    setActiveTab('sector');
    onApplyFilters({
      searchTerm: '',
      sector: '',
      duration: '',
      stage: '',
      skills: []
    });
  };

  const hasActiveFilters = searchTerm || selectedSector || selectedDuration || selectedStage || selectedSkills.length > 0;

  return (
    <div className="bg-white rounded-lg shadow-md p-6">
      <div className="flex items-center justify-between mb-6">
        <div className="flex items-center gap-2">
          <Filter className="h-5 w-5 text-blue-600" />
          <h2 className="text-lg font-semibold">Filtres</h2>
        </div>
        {hasActiveFilters && (
          <Button
            variant="ghost"
            size="sm"
            onClick={handleReset}
            className="text-gray-500 hover:text-gray-700"
          >
            Réinitialiser
          </Button>
        )}
      </div>

      <div className="relative mb-6">
        <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 h-4 w-4 text-gray-400" />
        <Input
          value={searchTerm}
          onChange={(e) => setSearchTerm(e.target.value)}
          placeholder="Rechercher un projet..."
          className="pl-10 pr-10"
        />
        {searchTerm && (
          <button
            onClick={() => setSearchTerm('')}
            className="absolute right-3 top-1/2 transform -translate-y-1/2"
          >
            <X className="h-4 w-4 text-gray-400 hover:text-gray-600" />
          </button>
        )}
      </div>

      <div className="flex justify-between mb-4">
        <div className="flex space-x-2">
          <div 
            className={`w-2 h-2 rounded-full ${activeTab === 'sector' ? 'bg-blue-500' : 'bg-gray-300'}`}
          />
          <div 
            className={`w-2 h-2 rounded-full ${activeTab === 'skills' ? 'bg-blue-500' : 'bg-gray-300'}`}
          />
          <div 
            className={`w-2 h-2 rounded-full ${activeTab === 'stage' ? 'bg-blue-500' : 'bg-gray-300'}`}
          />
          <div 
            className={`w-2 h-2 rounded-full ${activeTab === 'duration' ? 'bg-blue-500' : 'bg-gray-300'}`}
          />
        </div>
        <div className="text-sm text-gray-500">
          {activeTab === 'sector' && 'Étape 1: Secteur'}
          {activeTab === 'skills' && 'Étape 2: Compétences'}
          {activeTab === 'stage' && 'Étape 3: Stade'}
          {activeTab === 'duration' && 'Étape 4: Type'}
        </div>
      </div>

      <Tabs.Root value={activeTab} onValueChange={setActiveTab} className="space-y-6">
        <Tabs.List className="flex space-x-2 border-b">
          <Tabs.Trigger
            value="sector"
            className="px-3 py-2 text-sm font-medium text-gray-500 hover:text-gray-700 border-b-2 border-transparent data-[state=active]:border-blue-500 data-[state=active]:text-blue-600"
          >
            <div className="flex flex-col items-center">
              <Briefcase className="h-4 w-4 mb-1" />
              <span>Secteur</span>
            </div>
          </Tabs.Trigger>
          <Tabs.Trigger
            value="skills"
            className="px-3 py-2 text-sm font-medium text-gray-500 hover:text-gray-700 border-b-2 border-transparent data-[state=active]:border-blue-500 data-[state=active]:text-blue-600"
          >
            <div className="flex flex-col items-center">
              <Code className="h-4 w-4 mb-1" />
              <span>Compétences</span>
            </div>
          </Tabs.Trigger>
          <Tabs.Trigger
            value="stage"
            className="px-3 py-2 text-sm font-medium text-gray-500 hover:text-gray-700 border-b-2 border-transparent data-[state=active]:border-blue-500 data-[state=active]:text-blue-600"
          >
            <div className="flex flex-col items-center">
              <Star className="h-4 w-4 mb-1" />
              <span>Stade</span>
            </div>
          </Tabs.Trigger>
          <Tabs.Trigger
            value="duration"
            className="px-3 py-2 text-sm font-medium text-gray-500 hover:text-gray-700 border-b-2 border-transparent data-[state=active]:border-blue-500 data-[state=active]:text-blue-600"
          >
            <div className="flex flex-col items-center">
              <Clock className="h-4 w-4 mb-1" />
              <span>Type</span>
            </div>
          </Tabs.Trigger>
        </Tabs.List>

        <Tabs.Content value="sector" className="space-y-2">
          <div className="grid grid-cols-1 gap-2">
            {sectors.map((sector) => (
              <motion.div
                key={sector}
                whileHover={{ scale: 1.02 }}
                whileTap={{ scale: 0.98 }}
              >
                <Button
                  variant={selectedSector === sector ? 'default' : 'outline'}
                  size="sm"
                  className="justify-between w-full"
                  onClick={() => {
                    setSelectedSector(sector);
                    handleNextTab('sector');
                  }}
                >
                  <span>{sector}</span>
                  <ArrowRight className="h-4 w-4 opacity-0 group-hover:opacity-100 transition-opacity" />
                </Button>
              </motion.div>
            ))}
          </div>
        </Tabs.Content>

        <Tabs.Content value="skills" className="space-y-4">
          <div className="flex justify-between items-center">
            <h3 className="font-medium text-sm text-gray-700">Compétences pour {selectedSector}</h3>
            {selectedSkills.length > 0 && (
              <Button 
                variant="ghost" 
                size="sm" 
                onClick={() => handleNextTab('skills')}
                className="text-blue-600 flex items-center gap-1"
              >
                Suivant <ArrowRight className="h-3 w-3" />
              </Button>
            )}
          </div>
          <div className="flex flex-wrap gap-2">
            {getSkillsForSector(selectedSector).map((skill) => (
              <Button
                key={skill}
                variant={selectedSkills.includes(skill) ? 'default' : 'outline'}
                size="sm"
                onClick={() => {
                  const newSkills = selectedSkills.includes(skill)
                    ? selectedSkills.filter(s => s !== skill)
                    : [...selectedSkills, skill];
                  setSelectedSkills(newSkills);
                }}
              >
                {skill}
              </Button>
            ))}
          </div>
        </Tabs.Content>

        <Tabs.Content value="stage" className="space-y-4">
          <div className="flex justify-between items-center">
            <h3 className="font-medium text-sm text-gray-700">Stade du projet</h3>
            {selectedStage && (
              <Button 
                variant="ghost" 
                size="sm" 
                onClick={() => handleNextTab('stage')}
                className="text-blue-600 flex items-center gap-1"
              >
                Suivant <ArrowRight className="h-3 w-3" />
              </Button>
            )}
          </div>
          {stages.map((stage) => (
            <motion.div
              key={stage}
              whileHover={{ scale: 1.02 }}
              whileTap={{ scale: 0.98 }}
            >
              <Button
                variant={selectedStage === stage ? 'default' : 'outline'}
                className="w-full justify-between group"
                onClick={() => {
                  setSelectedStage(stage);
                  handleNextTab('stage');
                }}
              >
                <span>{stage}</span>
                <ArrowRight className="h-4 w-4 opacity-0 group-hover:opacity-100 transition-opacity" />
              </Button>
            </motion.div>
          ))}
        </Tabs.Content>

        <Tabs.Content value="duration" className="space-y-4">
          <h3 className="font-medium text-sm text-gray-700">Type de collaboration</h3>
          {durations.map((duration) => (
            <motion.div
              key={duration}
              whileHover={{ scale: 1.02 }}
              whileTap={{ scale: 0.98 }}
            >
              <Button
                variant={selectedDuration === duration ? 'default' : 'outline'}
                className="w-full justify-start"
                onClick={() => setSelectedDuration(duration)}
              >
                {duration}
              </Button>
            </motion.div>
          ))}
        </Tabs.Content>
      </Tabs.Root>

      {hasActiveFilters && (
        <div className="mt-6 pt-6 border-t">
          <div className="space-y-2 mb-4">
            <h3 className="font-medium text-sm text-gray-700">Filtres sélectionnés</h3>
            <div className="flex flex-wrap gap-2">
              {selectedSector && (
                <div className="bg-blue-100 text-blue-800 px-3 py-1 rounded-full text-sm">
                  {selectedSector}
                </div>
              )}
              {selectedSkills.map(skill => (
                <div key={skill} className="bg-green-100 text-green-800 px-3 py-1 rounded-full text-sm">
                  {skill}
                </div>
              ))}
              {selectedStage && (
                <div className="bg-purple-100 text-purple-800 px-3 py-1 rounded-full text-sm">
                  {selectedStage}
                </div>
              )}
              {selectedDuration && (
                <div className="bg-yellow-100 text-yellow-800 px-3 py-1 rounded-full text-sm">
                  {selectedDuration}
                </div>
              )}
            </div>
          </div>
          <Button
            className="w-full"
            onClick={handleApply}
          >
            Appliquer les filtres
          </Button>
        </div>
      )}
    </div>
  );
}