import React, { useEffect } from 'react';
import * as Dialog from '@radix-ui/react-dialog';
import { motion } from 'framer-motion';
import { X, Star, MapPin, Calendar, Briefcase, MessageSquare } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { useNavigate } from 'react-router-dom';
import { useQuery } from '@tanstack/react-query';
import { supabase } from '@/lib/supabase';
import { useAuth } from '@/hooks/use-auth';
import { useLocationStore } from '@/stores/location';
import { calculateDistance } from '@/lib/geolocation';
import type { Project, UserProfile } from '@/lib/types';

interface MatchModalProps {
  open: boolean;
  onOpenChange: (open: boolean) => void;
  item: Project | UserProfile;
  type: 'project' | 'talent';
}

// Custom Confetti component
const ConfettiAnimation = () => {
  return (
    <div className="absolute inset-0 overflow-hidden pointer-events-none">
      {Array.from({ length: 50 }).map((_, i) => (
        <motion.div
          key={i}
          initial={{ 
            x: Math.random() * window.innerWidth, 
            y: -20,
            opacity: 1,
            rotate: Math.random() * 360,
            scale: Math.random() * 0.5 + 0.5
          }}
          animate={{ 
            y: window.innerHeight + 50,
            opacity: 0
          }}
          transition={{ 
            duration: Math.random() * 2 + 2,
            delay: Math.random() * 0.5,
            ease: "linear"
          }}
          className="absolute w-4 h-4 rounded-sm"
          style={{ 
            backgroundColor: ['#FF5E5B', '#D8D8D8', '#FFFFEA', '#00CECB', '#FFED66', '#4D96FF', '#FF6B6B', '#C2F9BB'][Math.floor(Math.random() * 8)],
            boxShadow: '0 0 10px rgba(255,255,255,0.5)'
          }}
        />
      ))}
    </div>
  );
};

export function MatchModal({ open, onOpenChange, item, type }: MatchModalProps) {
  const navigate = useNavigate();
  const { user } = useAuth();
  const { selectedCity } = useLocationStore();
  const [playSound] = React.useState(true);

  // Play match sound effect
  useEffect(() => {
    if (open && playSound) {
      const audio = new Audio('/sounds/match-sound.mp3');
      audio.volume = 0.5;
      audio.play().catch(() => {
        // Ignore autoplay errors
      });
      return () => {
        audio.pause();
        audio.currentTime = 0;
      };
    }
  }, [open, playSound]);

  // Check if there's a match to show document access
  const { data: hasMatch } = useQuery({
    queryKey: ['match-document', item.id, user?.id],
    queryFn: async () => {
      if (!user?.id || type !== 'project') return false;
      
      const { data: profile } = await supabase
        .from('profiles')
        .select('id')
        .eq('user_id', user.id)
        .single();
      
      if (!profile) return false;
      
      const { data, error } = await supabase
        .from('project_matches')
        .select('*')
        .eq('project_id', item.id)
        .eq('seeker_id', profile.id)
        .single();
      
      return !!data && !error;
    },
    enabled: !!user?.id && type === 'project'
  });

  // Calculate distance between user and item
  const getDistance = () => {
    if (!selectedCity || !item.latitude || !item.longitude) return null;
    
    const distance = calculateDistance(
      selectedCity.latitude,
      selectedCity.longitude,
      item.latitude,
      item.longitude
    );
    
    return Math.round(distance);
  };

  const distance = getDistance();

  const handleMessage = () => {
    onOpenChange(false);
    navigate('/messages');
  };

  const experienceLevelText = {
    any: 'Tous niveaux acceptés',
    beginner: 'Débutant accepté',
    experienced: 'Expérimenté requis',
    junior: 'Junior',
    intermediaire: 'Intermédiaire',
    senior: 'Senior'
  };

  return (
    <Dialog.Root open={open} onOpenChange={onOpenChange}>
      <Dialog.Portal>
        <Dialog.Overlay className="fixed inset-0 bg-black/50" />
        <Dialog.Content className="fixed top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-full max-w-lg bg-white rounded-xl shadow-xl p-0 overflow-hidden">
          <Dialog.Title className="sr-only">Match !</Dialog.Title>
          <motion.div
            initial={{ opacity: 0, scale: 0.9 }}
            animate={{ opacity: 1, scale: 1 }}
            exit={{ opacity: 0, scale: 0.9 }}
            className="relative"
          >
            {/* Confetti animation */}
            <ConfettiAnimation />
            
            {/* Header Image */}
            <div className="h-48 bg-gradient-to-br from-blue-500 to-purple-600" />

            {/* Content */}
            <div className="p-6">
              <div className="flex items-start justify-between mb-6">
                <div>
                  <h2 className="text-2xl font-bold mb-2">
                    C'est un match !
                  </h2>
                  <p className="text-gray-600">
                    {type === 'project' 
                      ? 'Vous avez trouvé un projet intéressant !'
                      : 'Vous avez trouvé un talent prometteur !'}
                  </p>
                </div>
                <div className="flex items-center">
                  <Star className="h-8 w-8 text-yellow-400" />
                </div>
              </div>

              <div className="space-y-4 mb-6">
                <h3 className="text-xl font-semibold">
                  {type === 'project' ? (item as Project).title : (item as UserProfile).full_name}
                </h3>

                {item.city && (
                  <div className="flex items-center gap-2 text-gray-600">
                    <MapPin className="h-4 w-4" />
                    <span>{item.city}</span>
                  </div>
                )}

                {type === 'project' ? (
                  <div className="flex items-center gap-2 text-gray-600">
                    <Briefcase className="h-4 w-4" />
                    <span>{(item as Project).collaboration_type}</span>
                  </div>
                ) : (
                  <div className="flex items-center gap-2 text-gray-600">
                    <Calendar className="h-4 w-4" />
                    <span>{(item as UserProfile).availability}</span>
                  </div>
                )}

                <p className="text-gray-700">
                  {type === 'project' ? (item as Project).brief_description : (item as UserProfile).bio}
                </p>
              </div>

              <div className="flex gap-4">
                <Button
                  variant="outline"
                  onClick={() => onOpenChange(false)}
                  className="flex-1"
                >
                  Continuer à swiper
                </Button>
                <Button
                  onClick={handleMessage}
                  className="flex-1 flex items-center justify-center gap-2"
                >
                  <MessageSquare className="h-4 w-4" />
                  Envoyer un message
                </Button>
              </div>
            </div>

            <Dialog.Close className="absolute top-4 right-4 p-2 rounded-full bg-white/10 hover:bg-white/20">
              <X className="h-5 w-5 text-white" />
            </Dialog.Close>
          </motion.div>
        </Dialog.Content>
      </Dialog.Portal>
    </Dialog.Root>
  );
}