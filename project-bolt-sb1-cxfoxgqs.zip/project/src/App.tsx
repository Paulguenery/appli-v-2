import React from 'react';
import { BrowserRouter as Router, Routes, Route, Navigate } from 'react-router-dom';
import { Layout } from './components/Layout';
import { Auth } from './pages/Auth';
import { AuthCallback } from './pages/AuthCallback';
import { ProjectOwnerProfile } from './pages/ProjectOwnerProfile';
import { ProjectSeekerProfile } from './pages/ProjectSeekerProfile';
import { ProjectOwnerDashboard } from './pages/ProjectOwnerDashboard';
import { ProjectSeekerDashboard } from './pages/ProjectSeekerDashboard';
import { Messages } from './pages/Messages';
import { SearchProjects } from './pages/SearchProjects';
import { SearchTalents } from './pages/SearchTalents';
import { Subscribe } from './pages/Subscribe';
import { Calendar } from './pages/Calendar';
import { Favorites } from './pages/Favorites';
import { SuggestionsPage } from './components/suggestions/SuggestionsPage';
import { Settings } from './pages/Settings';
import { ReferralProgram } from './pages/ReferralProgram';
import { AuthProvider } from './hooks/use-auth';
import { QueryClient, QueryClientProvider } from '@tanstack/react-query';
import { SwipePage } from './pages/SwipePage';
import { SwipeUpPage } from './pages/SwipeUpPage';
import { GuestAccess } from './pages/GuestAccess';
import { GuestProjects } from './pages/GuestProjects';
import { GuestTalents } from './pages/GuestTalents';
import { AdminDashboard } from './pages/AdminDashboard';
import { TermsOfService } from './pages/TermsOfService';
import { PrivacyPolicy } from './pages/PrivacyPolicy';
import { SubscriptionTerms } from './pages/SubscriptionTerms';

const queryClient = new QueryClient();

function App() {
  return (
    <QueryClientProvider client={queryClient}>
      <AuthProvider>
        <Router>
          <Routes>
            <Route path="/" element={<Auth />} />
            <Route path="/auth/callback" element={<AuthCallback />} />
            <Route path="/subscribe" element={<Subscribe />} />
            <Route path="/calendar" element={<Calendar />} />
            <Route path="/search-projects" element={<SearchProjects />} />
            <Route path="/search-talents" element={<SearchTalents />} />
            <Route path="/swipe" element={<SwipePage />} />
            <Route path="/swipe-up" element={<SwipeUpPage />} />
            <Route path="/suggestions" element={<SuggestionsPage />} />
            <Route path="/settings" element={<Settings />} />
            <Route path="/referral" element={<ReferralProgram />} />
            <Route path="/terms" element={<TermsOfService />} />
            <Route path="/privacy" element={<PrivacyPolicy />} />
            <Route path="/subscription-terms" element={<SubscriptionTerms />} />
            <Route path="/admin" element={<AdminDashboard />} />
            
            {/* Guest access routes */}
            <Route path="/guest" element={<GuestAccess />} />
            <Route path="/guest/projects" element={<GuestProjects />} />
            <Route path="/guest/talents" element={<GuestTalents />} />
            <Route path="/guest/investor" element={<GuestProjects userType="investor" />} />
            
            <Route
              path="/owner/*"
              element={
                <Layout userType="project_owner">
                  <Routes>
                    <Route path="profile" element={<ProjectOwnerProfile />} />
                    <Route path="dashboard" element={<ProjectOwnerDashboard />} />
                    <Route path="messages" element={<Messages />} />
                    <Route path="favorites" element={<Favorites />} />
                    <Route path="search-talents" element={<SearchTalents />} />
                    <Route path="settings" element={<Settings />} />
                    <Route path="referral" element={<ReferralProgram />} />
                  </Routes>
                </Layout>
              }
            />
            <Route
              path="/seeker/*"
              element={
                <Layout userType="project_seeker">
                  <Routes>
                    <Route path="profile" element={<ProjectSeekerProfile />} />
                    <Route path="dashboard" element={<ProjectSeekerDashboard />} />
                    <Route path="messages" element={<Messages />} />
                    <Route path="favorites" element={<Favorites />} />
                    <Route path="search-projects" element={<SearchProjects />} />
                    <Route path="settings" element={<Settings />} />
                    <Route path="referral" element={<ReferralProgram />} />
                  </Routes>
                </Layout>
              }
            />
            <Route path="*" element={<Navigate to="/" replace />} />
          </Routes>
        </Router>
      </AuthProvider>
    </QueryClientProvider>
  );
}

export default App;