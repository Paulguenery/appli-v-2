/*
  # Amélioration du système de swipe et de recherche par localisation
  
  1. Modifications
    - Mise à jour de la fonction search_projects_by_location pour inclure tous les champs nécessaires
    - Ajout du support pour le champ ideal_partner_description
    - Ajout du support pour le champ open_to_investment
    - Optimisation des performances de recherche
    
  2. Sécurité
    - Maintien des politiques RLS existantes
    - Maintien des permissions d'exécution pour les utilisateurs authentifiés
*/

-- Drop existing function
DROP FUNCTION IF EXISTS public.search_projects_by_location(float8, float8, float8);

-- Create updated function with all necessary fields
CREATE OR REPLACE FUNCTION public.search_projects_by_location(
  center_lat float8,
  center_lon float8,
  radius_km float8
)
RETURNS TABLE (
  id uuid,
  title text,
  description text,
  brief_description text,
  full_description_url text,
  category text,
  required_skills text[],
  collaboration_type text,
  experience_level text,
  distance float8,
  owner_id uuid,
  city text,
  latitude float8,
  longitude float8,
  created_at timestamptz,
  open_to_investment boolean,
  ideal_partner_description text,
  image_url text
)
LANGUAGE plpgsql
SECURITY DEFINER
AS $$
BEGIN
  RETURN QUERY
  SELECT 
    p.id,
    p.title,
    p.description,
    p.brief_description,
    p.full_description_url,
    p.category,
    p.required_skills,
    p.collaboration_type,
    p.experience_level,
    public.calculate_distance(center_lat, center_lon, p.latitude, p.longitude) as distance,
    p.owner_id,
    prof.city,
    p.latitude,
    p.longitude,
    p.created_at,
    COALESCE(p.open_to_investment, false) as open_to_investment,
    p.ideal_partner_description,
    p.image_url
  FROM projects p
  LEFT JOIN profiles prof ON p.owner_id = prof.id
  WHERE 
    p.latitude IS NOT NULL 
    AND p.longitude IS NOT NULL
    AND public.calculate_distance(center_lat, center_lon, p.latitude, p.longitude) <= radius_km
  ORDER BY distance ASC;
END;
$$;

-- Grant execute permissions to authenticated users
GRANT EXECUTE ON FUNCTION public.search_projects_by_location TO authenticated;

-- Update search_profiles_by_location function to include more fields
DROP FUNCTION IF EXISTS public.search_profiles_by_location(float8, float8, float8, text);

CREATE OR REPLACE FUNCTION public.search_profiles_by_location(
  center_lat float8,
  center_lon float8,
  radius_km float8,
  role_filter text DEFAULT NULL
)
RETURNS TABLE (
  id uuid,
  full_name text,
  city text,
  bio text,
  skills text[],
  sectors text[],
  experience_level text,
  availability text,
  is_verified boolean,
  user_type text,
  distance float8,
  latitude float8,
  longitude float8,
  created_at timestamptz,
  avatar_url text,
  average_rating float8,
  total_ratings int
)
LANGUAGE plpgsql
SECURITY DEFINER
AS $$
BEGIN
  RETURN QUERY
  SELECT 
    p.id,
    p.full_name,
    p.city,
    p.bio,
    p.skills,
    p.sectors,
    p.experience_level,
    p.availability,
    p.is_verified,
    p.user_type,
    public.calculate_distance(center_lat, center_lon, p.latitude, p.longitude) as distance,
    p.latitude,
    p.longitude,
    p.created_at,
    p.avatar_url,
    p.average_rating,
    p.total_ratings
  FROM profiles p
  WHERE 
    p.latitude IS NOT NULL 
    AND p.longitude IS NOT NULL
    AND public.calculate_distance(center_lat, center_lon, p.latitude, p.longitude) <= radius_km
    AND (role_filter IS NULL OR p.role = role_filter)
  ORDER BY distance ASC;
END;
$$;

-- Grant execute permissions to authenticated users
GRANT EXECUTE ON FUNCTION public.search_profiles_by_location TO authenticated;